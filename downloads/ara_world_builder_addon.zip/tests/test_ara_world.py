import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from PIL import Image

from generator.ara_world import generate_world, validate_map


SAMPLE_MAP = {
    "meta": {"crs": "EPSG:32722", "radius_m": 80, "origin_lonlat": [-50.43568, -21.22224]},
    "blocks": [{"id": "block_a", "zone": "residential", "polygons": [[[
        [-34, -30], [34, -30], [34, 30], [-34, 30], [-34, -30]
    ]]]}],
    "lots": [
        {"id": "lot_house", "zone": "residential", "polygons": [[[
            [-25, -18], [-2, -18], [-2, 18], [-25, 18], [-25, -18]
        ]]]},
        {"id": "lot_empty", "zone": "residential", "polygons": [[[
            [3, -18], [25, -18], [25, 18], [3, 18], [3, -18]
        ]]]},
    ],
    "buildings": [{"id": "house_a", "lot_id": "lot_house", "building_type": "house", "polygons": [[[
        [-20, -9], [-7, -9], [-7, 9], [-20, 9], [-20, -9]
    ]]]}],
    "roads": [{"id": 1, "name": "Avenida Teste", "highway": "primary", "width_m": 14,
               "lines": [[[-80, 0], [80, 0]]]}],
    "trees": [{"id": 12, "point": [28, 20]}],
}


class AraWorldTests(unittest.TestCase):
    def test_rejects_wrong_crs_or_missing_roads(self):
        bad = dict(SAMPLE_MAP)
        bad["meta"] = {"crs": "EPSG:4326"}
        with self.assertRaises(ValueError):
            validate_map(bad)
        bad = dict(SAMPLE_MAP)
        bad["roads"] = []
        with self.assertRaises(ValueError):
            validate_map(bad)

    def test_generates_game_map_controls_atlases_and_zip(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)
            result = generate_world(SAMPLE_MAP, out)
            expected = [
                "aracatexas_preview.png", "aracatexas_tileset.png",
                "aracatexas_buildings.png", "aracatexas_map.json",
                "control_ground.png", "control_zones.png", "control_roads.png",
                "control_buildings.png", "chunk_index.json", "manifest.json",
                "README.txt", "aracatexas_visual_world.zip",
            ]
            for filename in expected:
                self.assertTrue((out / filename).is_file(), filename)
            with Image.open(out / "aracatexas_preview.png") as preview:
                self.assertGreater(preview.width, 100)
                self.assertGreater(preview.height, 100)
            with Image.open(out / "aracatexas_tileset.png") as tiles:
                self.assertEqual(tiles.size, (256, 128))
            with Image.open(out / "aracatexas_buildings.png") as buildings:
                self.assertEqual(buildings.size, (256, 128))
            game_map = json.loads((out / "aracatexas_map.json").read_text(encoding="utf-8"))
            self.assertEqual(game_map["meta"]["crs"], "EPSG:32722")
            self.assertEqual(game_map["visual"]["tile_size_px"], 32)
            self.assertGreaterEqual(len(game_map["trees"]), len(SAMPLE_MAP["trees"]))
            self.assertEqual(result["counts"]["roads"], 1)
            self.assertTrue((out / "aracatexas_visual_world.zip").stat().st_size > 1000)

    def test_same_seed_produces_same_preview(self):
        with tempfile.TemporaryDirectory() as temp:
            first, second = Path(temp) / "a", Path(temp) / "b"
            generate_world(SAMPLE_MAP, first, seed=77)
            generate_world(SAMPLE_MAP, second, seed=77)
            hash_a = hashlib.sha256((first / "aracatexas_preview.png").read_bytes()).hexdigest()
            hash_b = hashlib.sha256((second / "aracatexas_preview.png").read_bytes()).hexdigest()
            self.assertEqual(hash_a, hash_b)


if __name__ == "__main__":
    unittest.main()
